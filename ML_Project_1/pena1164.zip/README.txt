extract pena1164.zip into a folder called "pena1164"
cd into "pena1164"
note: in there, you should see a "client.jar" and a "data" directory
execute" "java -jar client.jar"